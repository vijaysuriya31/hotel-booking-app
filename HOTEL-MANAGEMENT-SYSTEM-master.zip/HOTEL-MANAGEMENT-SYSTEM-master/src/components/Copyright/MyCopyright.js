import React from 'react'
import './MyCopyright.css'
const MyCopyright = () => {
    return (
        <div className='copyrightBar'>
            <p>The Hotel Booking Website  © 2006-2021 THBW</p>
        </div>
    )
}

export default MyCopyright